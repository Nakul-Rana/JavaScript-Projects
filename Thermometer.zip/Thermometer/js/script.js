const thermometer = document.getElementById('thermometer');

const loadTemp = ()=>{
    thermometer.innerHTML = "&#xf2cb";
    thermometer.style.color = "yellow";
    setTimeout(()=>{
        thermometer.innerHTML = "&#xf2ca";
    },1000);

    setTimeout(()=>{
        thermometer.innerHTML = "&#xf2c9";
    },2000);

    setTimeout(()=>{
        thermometer.innerHTML = "&#xf2c8";
    },3000);

    setTimeout(()=>{
        thermometer.innerHTML = "&#xf2c7";
        thermometer.style.color = "red"
    },4000);
}

loadTemp();
setInterval(loadTemp, 5000);