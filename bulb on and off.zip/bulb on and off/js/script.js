onBtn = document.querySelector('.on_bulb');
offBtn = document.querySelector('.off_bulb');
bulb = document.querySelector(".images img");
onBtn.addEventListener("click",()=>{
    bulb.setAttribute("src","./img/on.png");
})
offBtn.addEventListener("click",()=>{
    bulb.setAttribute("src","./img/off.png")
})