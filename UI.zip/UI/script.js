window.addEventListener("DOMContentLoaded", () => {
    const text = "Start building magic today.";
    const container = document.getElementById("animated-text");
  
    text.split("").forEach((char, index) => {
      const span = document.createElement("span");
      span.textContent = char;
      span.style.animationDelay = `${index * 0.1}s`;
      container.appendChild(span);
    });
  });
  